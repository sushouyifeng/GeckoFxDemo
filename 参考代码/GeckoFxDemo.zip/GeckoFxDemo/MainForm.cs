﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GeckoFxDemo
{
    /// <summary>
    /// Defines the Main Window Class
    /// </summary>
    public partial class MainForm : Form
    {
        #region constructor
        /// <summary>
        /// 
        /// </summary>
        public MainForm()
        {
            InitializeComponent();

            m_geckoBrsr.ProgressChanged += m_geckoBrsr_ProgressChanged;

            m_geckoBrsr.DocumentCompleted += m_geckoBrsr_DocumentCompleted;

            m_geckoBrsr.HandleCreated += m_geckoBrsr_HandleCreated;
        }
        /// <summary>
        /// 
        /// </summary>
        ~MainForm()
        {
            m_geckoBrsr.ProgressChanged -= m_geckoBrsr_ProgressChanged;

            m_geckoBrsr.DocumentCompleted -= m_geckoBrsr_DocumentCompleted;

            m_geckoBrsr.HandleCreated -= m_geckoBrsr_HandleCreated;
        }
        #endregion

        #region methods
        /// <summary>
        /// 
        /// </summary>
        private void ShowDefaultPage()
        {
            string defaultDoc = string.Format("{0}\\browserinfo.html", System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location));

            if (System.IO.File.Exists(defaultDoc))
            {
                Navigate(defaultDoc);
            }
            else
            {
                Navigate(string.Empty);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="url"></param>
        private void Navigate(string url)
        {
            if (string.IsNullOrWhiteSpace(url))
            {
                m_geckoBrsr.Navigate("about:blank");
            }
            else
            {
                m_geckoBrsr.Navigate(url);
            }
        }
        #endregion

        #region handlers
        /// <summary>
        /// Handles loading document progress changed events.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void m_geckoBrsr_ProgressChanged(object sender, Skybound.Gecko.GeckoProgressEventArgs e)
        {
            if (0 < e.CurrentProgress && 100 != e.CurrentProgress)
            {
                m_txtUrl.Text = System.Text.RegularExpressions.Regex.Unescape(m_geckoBrsr.Url.AbsoluteUri);

                m_txtStatus.Text = string.Format("Loading {0}", m_geckoBrsr.Url);
            }
            else
            {
                m_txtStatus.Text = string.Format("Ready");
            }
        }
        /// <summary>
        /// Handles browser control document loading completed events.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void m_geckoBrsr_DocumentCompleted(object sender, EventArgs e)
        {
            m_txtUrl.Text = System.Text.RegularExpressions.Regex.Unescape(m_geckoBrsr.Url.AbsoluteUri);

            m_txtStatus.Text = string.Format("Ready");
        }
        /// <summary>
        /// Handles url text box key up events.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void m_txtUrl_KeyUp(object sender, KeyEventArgs e)
        {
            if (Keys.Enter == e.KeyCode)
            {
                Navigate(m_txtUrl.Text);
            }
            else
            {
                //ignored...
            }
        }
        /// <summary>
        /// Handles the go button clicked events.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void m_btnGo_Click(object sender, EventArgs e)
        {
            Navigate(m_txtUrl.Text);
        }
        /// <summary>
        /// Handles browser control handle created event.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void m_geckoBrsr_HandleCreated(object sender, EventArgs e)
        {
            ShowDefaultPage();
        }
        #endregion
    }
}
