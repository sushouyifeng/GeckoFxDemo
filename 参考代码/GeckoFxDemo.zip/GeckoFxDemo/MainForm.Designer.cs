﻿namespace GeckoFxDemo
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.m_geckoBrsr = new Skybound.Gecko.GeckoWebBrowser();
            this.m_topPane = new System.Windows.Forms.Panel();
            this.m_splitPaneTop = new System.Windows.Forms.SplitContainer();
            this.m_txtUrl = new System.Windows.Forms.TextBox();
            this.m_btnGo = new System.Windows.Forms.Button();
            this.m_splitPane = new System.Windows.Forms.SplitContainer();
            this.m_statusStrip = new System.Windows.Forms.StatusStrip();
            this.m_txtStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.m_topPane.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.m_splitPaneTop)).BeginInit();
            this.m_splitPaneTop.Panel1.SuspendLayout();
            this.m_splitPaneTop.Panel2.SuspendLayout();
            this.m_splitPaneTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.m_splitPane)).BeginInit();
            this.m_splitPane.Panel1.SuspendLayout();
            this.m_splitPane.Panel2.SuspendLayout();
            this.m_splitPane.SuspendLayout();
            this.m_statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // m_geckoBrsr
            // 
            this.m_geckoBrsr.Dock = System.Windows.Forms.DockStyle.Fill;
            this.m_geckoBrsr.Location = new System.Drawing.Point(0, 0);
            this.m_geckoBrsr.Name = "m_geckoBrsr";
            this.m_geckoBrsr.Size = new System.Drawing.Size(792, 390);
            this.m_geckoBrsr.TabIndex = 0;
            // 
            // m_topPane
            // 
            this.m_topPane.Controls.Add(this.m_splitPaneTop);
            this.m_topPane.Dock = System.Windows.Forms.DockStyle.Fill;
            this.m_topPane.Location = new System.Drawing.Point(0, 0);
            this.m_topPane.Name = "m_topPane";
            this.m_topPane.Size = new System.Drawing.Size(792, 25);
            this.m_topPane.TabIndex = 2;
            // 
            // m_splitPaneTop
            // 
            this.m_splitPaneTop.Dock = System.Windows.Forms.DockStyle.Fill;
            this.m_splitPaneTop.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.m_splitPaneTop.IsSplitterFixed = true;
            this.m_splitPaneTop.Location = new System.Drawing.Point(0, 0);
            this.m_splitPaneTop.Margin = new System.Windows.Forms.Padding(0);
            this.m_splitPaneTop.Name = "m_splitPaneTop";
            // 
            // m_splitPaneTop.Panel1
            // 
            this.m_splitPaneTop.Panel1.Controls.Add(this.m_txtUrl);
            // 
            // m_splitPaneTop.Panel2
            // 
            this.m_splitPaneTop.Panel2.Controls.Add(this.m_btnGo);
            this.m_splitPaneTop.Size = new System.Drawing.Size(792, 25);
            this.m_splitPaneTop.SplitterDistance = 736;
            this.m_splitPaneTop.TabIndex = 5;
            // 
            // m_txtUrl
            // 
            this.m_txtUrl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.m_txtUrl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.m_txtUrl.Location = new System.Drawing.Point(0, 0);
            this.m_txtUrl.Margin = new System.Windows.Forms.Padding(0);
            this.m_txtUrl.Name = "m_txtUrl";
            this.m_txtUrl.Size = new System.Drawing.Size(736, 20);
            this.m_txtUrl.TabIndex = 0;
            this.m_txtUrl.KeyUp += new System.Windows.Forms.KeyEventHandler(this.m_txtUrl_KeyUp);
            // 
            // m_btnGo
            // 
            this.m_btnGo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.m_btnGo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.m_btnGo.Location = new System.Drawing.Point(0, 0);
            this.m_btnGo.Name = "m_btnGo";
            this.m_btnGo.Size = new System.Drawing.Size(52, 25);
            this.m_btnGo.TabIndex = 1;
            this.m_btnGo.Text = "Go";
            this.m_btnGo.UseVisualStyleBackColor = true;
            this.m_btnGo.Click += new System.EventHandler(this.m_btnGo_Click);
            // 
            // m_splitPane
            // 
            this.m_splitPane.Dock = System.Windows.Forms.DockStyle.Fill;
            this.m_splitPane.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.m_splitPane.IsSplitterFixed = true;
            this.m_splitPane.Location = new System.Drawing.Point(0, 0);
            this.m_splitPane.Name = "m_splitPane";
            this.m_splitPane.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // m_splitPane.Panel1
            // 
            this.m_splitPane.Panel1.Controls.Add(this.m_topPane);
            // 
            // m_splitPane.Panel2
            // 
            this.m_splitPane.Panel2.Controls.Add(this.m_statusStrip);
            this.m_splitPane.Panel2.Controls.Add(this.m_geckoBrsr);
            this.m_splitPane.Size = new System.Drawing.Size(792, 416);
            this.m_splitPane.SplitterDistance = 25;
            this.m_splitPane.SplitterWidth = 1;
            this.m_splitPane.TabIndex = 3;
            // 
            // m_statusStrip
            // 
            this.m_statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.m_txtStatus});
            this.m_statusStrip.Location = new System.Drawing.Point(0, 368);
            this.m_statusStrip.Name = "m_statusStrip";
            this.m_statusStrip.Size = new System.Drawing.Size(792, 22);
            this.m_statusStrip.TabIndex = 1;
            this.m_statusStrip.Text = "statusStrip1";
            // 
            // m_txtStatus
            // 
            this.m_txtStatus.Name = "m_txtStatus";
            this.m_txtStatus.Size = new System.Drawing.Size(38, 17);
            this.m_txtStatus.Text = "Ready";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 416);
            this.Controls.Add(this.m_splitPane);
            this.Name = "MainForm";
            this.Text = "GeckoFX Demo - http://blog.csdn.net/freedigits";
            this.m_topPane.ResumeLayout(false);
            this.m_splitPaneTop.Panel1.ResumeLayout(false);
            this.m_splitPaneTop.Panel1.PerformLayout();
            this.m_splitPaneTop.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.m_splitPaneTop)).EndInit();
            this.m_splitPaneTop.ResumeLayout(false);
            this.m_splitPane.Panel1.ResumeLayout(false);
            this.m_splitPane.Panel2.ResumeLayout(false);
            this.m_splitPane.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.m_splitPane)).EndInit();
            this.m_splitPane.ResumeLayout(false);
            this.m_statusStrip.ResumeLayout(false);
            this.m_statusStrip.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Skybound.Gecko.GeckoWebBrowser m_geckoBrsr;
        private System.Windows.Forms.Panel m_topPane;
        private System.Windows.Forms.TextBox m_txtUrl;
        private System.Windows.Forms.SplitContainer m_splitPane;
        private System.Windows.Forms.SplitContainer m_splitPaneTop;
        private System.Windows.Forms.Button m_btnGo;
        private System.Windows.Forms.StatusStrip m_statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel m_txtStatus;
    }
}

