﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace GeckoFxDemo
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            string xulDirPath = GetXulRunnerPath();             //gets the default xulrunner dir path

            //normally starts the program if dir exists, quits otherwise
            if (System.IO.Directory.Exists(xulDirPath))
            {
                Skybound.Gecko.Xpcom.Initialize(xulDirPath);    //init with the dir path

                Application.Run(new MainForm());
            }
            else
            {
                MessageBox.Show(string.Format("XULRUNNER directory not found:\r\n{0}", xulDirPath), "Starting Program Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                Environment.ExitCode = 1;                       //sets abnormal exit code

                //quits...
            }
        }

        /// <summary>
        /// Gets the default XULRunner's dir path (i.e. "exeDirPath/xulrunner/").
        /// </summary>
        /// <returns>Returns the full dir path.</returns>
        static string GetXulRunnerPath()
        {
            return string.Format("{0}\\xulrunner\\", System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location));
        }
    }
}
